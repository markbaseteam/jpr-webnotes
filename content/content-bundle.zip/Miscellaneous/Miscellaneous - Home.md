---
dg-publish: true
---
[[Home]]
<center><h1> Miscellaneous </h1></center>

This is a work in progress...